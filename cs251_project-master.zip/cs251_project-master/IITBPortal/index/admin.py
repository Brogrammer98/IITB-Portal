from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Student)
admin.site.register(Course)
admin.site.register(Assignment)
admin.site.register(Course_Material)
admin.site.register(Interest)
admin.site.register(Topic)
admin.site.register(Quiz)
admin.site.register(News_feed)
admin.site.register(Question)
admin.site.register(Grade)
admin.site.register(Answer_record)